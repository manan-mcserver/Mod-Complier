package com.galaxy.autototem.mixin;

import com.galaxy.autototem.AutoTotemClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerMixin {
    @Inject(method = "handleEntityEvent", at = @At("HEAD"))
    private void autototem$detectLocalPlayerTotemPop(ClientboundEntityEventPacket packet, CallbackInfo ci) {
        Minecraft client = Minecraft.getInstance();
        // Event 35 is the vanilla totem-pop status event. Ignore other entities' pops.
        if (client.player != null
            && packet.getId() == client.player.getId()
            && packet.getEventId() == 35) {
            AutoTotemClient.onTotemPop();
        }
    }
}
