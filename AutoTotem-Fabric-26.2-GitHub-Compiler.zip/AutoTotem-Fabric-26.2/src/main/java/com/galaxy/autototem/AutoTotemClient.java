package com.galaxy.autototem;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

public final class AutoTotemClient implements ClientModInitializer {
    private static KeyMapping toggleKey;
    private static boolean enabled = true;

    private enum Phase { IDLE, WAIT_TO_OPEN, KEEP_INVENTORY_OPEN, VERIFY_SWAP, WAIT_TO_CLOSE }
    private static Phase phase = Phase.IDLE;
    private static int ticksLeft = 0;
    private static int swapRetries = 0;
    private static boolean openedByMod = false;

    // 20 game ticks = 1 second. Keep the inventory visibly open for 6 ticks (about 300 ms)
    // before attempting the offhand swap.
    private static final int POP_TO_OPEN_TICKS = 2;
    private static final int VISIBLE_INVENTORY_TICKS = 6;
    private static final int VERIFY_TICKS = 2;
    private static final int CLOSE_AFTER_SWAP_TICKS = 2;
    private static final int MAX_SWAP_RETRIES = 3;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.autototem.toggle",
            GLFW.GLFW_KEY_V,
            KeyMapping.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) {
                enabled = !enabled;
                if (!enabled) resetSequence(client);
            }

            if (!enabled || client.player == null || client.level == null || client.gameMode == null) return;
            if (phase == Phase.IDLE) return;

            if (ticksLeft > 0) {
                ticksLeft--;
                if (ticksLeft > 0) return;
            }

            switch (phase) {
                case WAIT_TO_OPEN -> {
                    // Do not take over another screen (chat, chest, pause menu, etc.).
                    if (client.screen != null) {
                        resetSequence(client);
                        return;
                    }
                    client.setScreen(new InventoryScreen(client.player));
                    openedByMod = true;
                    phase = Phase.KEEP_INVENTORY_OPEN;
                    ticksLeft = VISIBLE_INVENTORY_TICKS;
                }
                case KEEP_INVENTORY_OPEN -> {
                    if (!(client.screen instanceof InventoryScreen)
                        || client.player.containerMenu != client.player.inventoryMenu) {
                        resetSequence(client);
                        return;
                    }
                    if (isTotem(client.player.getOffhandItem())) {
                        phase = Phase.WAIT_TO_CLOSE;
                        ticksLeft = CLOSE_AFTER_SWAP_TICKS;
                    } else {
                        boolean clicked = clickSpareTotem(client);
                        if (clicked) {
                            phase = Phase.VERIFY_SWAP;
                            ticksLeft = VERIFY_TICKS;
                        } else {
                            // No spare totem was found; leave the inventory open only for the
                            // configured visible interval, then close it cleanly.
                            phase = Phase.WAIT_TO_CLOSE;
                            ticksLeft = CLOSE_AFTER_SWAP_TICKS;
                        }
                    }
                }
                case VERIFY_SWAP -> {
                    if (isTotem(client.player.getOffhandItem())) {
                        phase = Phase.WAIT_TO_CLOSE;
                        ticksLeft = CLOSE_AFTER_SWAP_TICKS;
                    } else if (swapRetries++ < MAX_SWAP_RETRIES
                        && client.screen instanceof InventoryScreen
                        && client.player.containerMenu == client.player.inventoryMenu) {
                        // Retry if the inventory update did not put the totem in the offhand.
                        ticksLeft = 2;
                        phase = Phase.KEEP_INVENTORY_OPEN;
                    } else {
                        phase = Phase.WAIT_TO_CLOSE;
                        ticksLeft = CLOSE_AFTER_SWAP_TICKS;
                    }
                }
                case WAIT_TO_CLOSE -> {
                    if (openedByMod && client.screen instanceof InventoryScreen) {
                        client.setScreen(null);
                    }
                    resetSequence(client);
                }
                default -> { }
            }
        });
    }

    public static void onTotemPop() {
        Minecraft client = Minecraft.getInstance();
        if (!enabled || client.player == null || client.level == null || phase != Phase.IDLE) return;
        if (isTotem(client.player.getOffhandItem())) return;
        swapRetries = 0;
        openedByMod = false;
        phase = Phase.WAIT_TO_OPEN;
        ticksLeft = POP_TO_OPEN_TICKS;
    }

    private static boolean clickSpareTotem(Minecraft client) {
        if (client.player == null || client.gameMode == null) return false;
        if (isTotem(client.player.getOffhandItem())) return true;

        AbstractContainerMenu menu = client.player.inventoryMenu;
        if (client.player.containerMenu != menu) return false;

        // Player inventory menu slots 9–35 = main inventory; 36–44 = hotbar.
        // SWAP button 40 is the offhand slot in the vanilla player inventory menu.
        for (int slot = 9; slot <= 44; slot++) {
            if (menu.getSlot(slot).hasItem() && isTotem(menu.getSlot(slot).getItem())) {
                client.gameMode.handleInventoryMouseClick(
                    menu.containerId, slot, 40, ClickType.SWAP, client.player
                );
                return true;
            }
        }
        return false;
    }

    private static boolean isTotem(net.minecraft.world.item.ItemStack stack) {
        return !stack.isEmpty() && stack.is(Items.TOTEM_OF_UNDYING);
    }

    private static void resetSequence(Minecraft client) {
        phase = Phase.IDLE;
        ticksLeft = 0;
        swapRetries = 0;
        openedByMod = false;
    }
}
