# Auto Totem — Fabric 26.2 source project (revision 2)

This ZIP contains source code, not a compiled JAR. It has not been compiled or tested against the final Minecraft 26.2 mappings in this environment.

## Changes in this revision
- Default toggle key is **V** and is registered in Minecraft Controls as **Toggle Auto Totem** (under Miscellaneous).
- The inventory opens 2 ticks after the local player's totem-pop event.
- The inventory remains visibly open for **6 ticks (about 300 ms)** before the offhand swap is attempted.
- The mod verifies that the offhand actually contains a totem and retries up to 3 times if the client still has a spare totem.
- It now filters the pop event to the local player, not other players/entities.
- The inventory is closed 2 ticks after a successful swap (or after attempts finish).
- No HUD indicator or action-bar status message is displayed.

The delays are for readable timing and normal gameplay; they are not an anti-cheat bypass. Server-side inventory rules and anti-cheat may still reject automated inventory actions.

## Build requirements
- JDK 25
- Internet access to resolve the exact Minecraft, Fabric Loader, Fabric API, and Loom dependencies
- A Gradle installation or Gradle Wrapper

Open the folder as a Gradle project in IntelliJ IDEA and run `build`. The output JAR should be in `build/libs/` if the chosen 26.2 mappings and APIs match these sources.

## Compatibility warning
This is an uncompiled source draft. Minecraft 26.2 is a fast-moving target and packet/accessor names and Fabric API versions may need adjustment against the exact released 26.2 artifacts. Do not install this as a JAR; there is no compiled JAR in this ZIP.
